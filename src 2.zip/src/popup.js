onload = function popup() { 
    document.getElementById('run').onclick = function(){
        alert("RUN");
    }
}